package Day4;
import java.util.*;

public class Task10 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		int sum=0;
		int res=0;
		while(num>0) {
			int temp=num%10;
			sum= sum+temp;
			num= num/10;
		}
		int var=sum%10;
		int var2=sum/10;
		res=var+var2;
		System.out.println(res);
		
			
			
		}
		

	}


