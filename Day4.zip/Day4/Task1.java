package Day4;

//DISPLAY FROM 1 TO 10 USING FOR LOOP 

public class Task1 {

	public static void main(String[] args) {
		int num=10;
		for(int i=0;i<num;i=i+2) {
			System.out.println(i);
		}
		
	}

}
