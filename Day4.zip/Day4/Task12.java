package Day4;
import java.util.*;

public class Task12 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num=10;
		do {
			System.out.println(num);
			num++;
		}while(num!=11);
		
	}

}
