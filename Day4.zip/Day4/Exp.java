package Day4;

//FOR LOOP


public class Exp {

	public static void main(String[] args) {
		int num=10;
		for(int i=0;i<num;i++) {
			System.out.println(i);
			
		}
			

	}

}
