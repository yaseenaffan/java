package Day4;

//DISPLAY EVEN NO FROM 1 TO 10 IN REVERSE

public class Task2 {

	public static void main(String[] args) {
		int num=0;
		for(int i=10;i>=num;i=i-2) {
			System.out.println(i);
		}
	}

}
