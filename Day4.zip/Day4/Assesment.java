package Day4;

// AMSTRING NO

import java.util.*;

public class Assesment {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        
        System.out.println("Enter the number:");
        int num = sc.nextInt();
        int a = num;  
        int b = 0;
        int sum = 0;

        
        int temp = num;
        while (temp > 0) {
            b++;
            temp = temp / 10;
        }

        
        temp = num;
        while (temp > 0) {
            int digit = temp % 10;  
            int power = 1;

            for (int i = 0; i < b; i++) {
                power = power * digit;
            }

            sum = sum + power;
            temp = temp / 10;
        }

        
        if (sum == a) {
            System.out.println( a + " is an Armstrong number.");
        } else {
            System.out.println( a + " is not an Armstrong number.");
        }

        
    }
}
