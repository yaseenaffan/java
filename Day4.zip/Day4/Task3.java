package Day4;
// EVEN COUNT USING FOR AND IF 

import java.util.*;
public class Task3 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int st=sc.nextInt();
		int end=sc.nextInt();
		int evencount=0;
		for(int i=st ;i<=end;i++) {
			if(i%2==0)
			{
				
				evencount++;
				
			}
			if(i%2!=0);
		}
		System.out.println(evencount);
	}

}
