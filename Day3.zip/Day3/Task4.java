package Day3;

//WEIGHT OF MELON 

import java.util.Scanner;
public class Task4 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the weight of the watermelon");
		int weight=sc.nextInt();
		
		if(weight>=0 && weight<=100)
		{
			if(weight%2==0)
			{
				System.out.println("YES");
			    System.out.println(weight/2+" "+ " "+weight/2);
			}
		
		else 
		{
			System.out.println("NO");
		}
		
	}
	else
	{
		System.out.println("INVALID INPUT");
	}
	}}