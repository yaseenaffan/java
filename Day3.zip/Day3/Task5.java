package Day3;

// SWITCH CASE EXAMPLE

import java.util.Scanner;
public class Task5 {

	public static void main(String[] args) {
		int num=0;
		switch(num) {
		case 0:{
			System.out.println("sunday");
		}
		// here we are using break to stop the execution it is similar to else statement
		case 1:{
			System.out.println("monday");
		}
		case 2:{
			System.out.println("tuesday");
		}
		case 3:{
			System.out.println("wednesday");
		}
		case 4:{
			System.out.println("thursday");
		}
		case 5:{
			System.out.println("friday");
		}
		case 6:{
			System.out.println("saturday");
		}
		break;
		
		default:{
			System.out.println("nothing");
		
		}
		
		}
		
		

	}

}
