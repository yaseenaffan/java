package Day3;
// EXAMPLE OF IF STATEMENTS
import java.util.Scanner;

public class Task1 {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		int a= scan.nextInt();
		int b= scan.nextInt();
		if(a%3==0&&b%5==0)
		{
		System.out.println("FIZZBIZZ");
		}
		else if(a%3==0)
		{
			System.out.println("FIZZ");
		}
		else if (b%5==0)
		{
			System.out.println("BIZZ ");
		}
		
		
		
		

	}

}
