package Day3;
//PROGRAM FOR GRADE USING IF STATEMENTS
import java.util.Scanner;

public class Task2 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		int a=sc.nextInt();
		
		if(90<=a && a<=100){
			System.out.println("A+");
		}
		else if(80<=a && a<=89)
		{
			System.out.println("A");
		}
		else if(70<=a && a<=79)
		{
			System.out.println("b");
		}
		else if(60<=a && 69>=a)
		{
			System.out.println("c");
		}
		else if(50<=a && 59>=a)
		{
			System.out.println("d");
		}
		

	}

}
