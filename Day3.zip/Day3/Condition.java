package Day3;

public class Condition {

	public static void main(String[] args) {
		
		int num=9;
		if(num==9)
		{
			System.out.println("the num is = to nine");
		}
		if(num>7) 
		{
			System.out.println("the num is > 7");
		}
		if(num<10)
		{
			System.out.println("the num is < 10");
			
		}
		else
			System.out.println("nothing");
	}

}
