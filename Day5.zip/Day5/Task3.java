package Day5;

// PRINT STRING USING FOR LOOP

public class Task3 {

    public static void main(String[] args) {
        String[] fruits = {"apple", "orange", "banana", "lemon"};
        
        for (int i = 0; i < fruits.length; i++) {
            System.out.println(fruits[i]);
        }
    }
}
