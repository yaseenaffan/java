package Day5;

// TO FIND PALINDROME OR NOT

import java.util.*;

public class Task1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		int rev=0;
		int a=0;
		int b=num;
		int temp1=num;
		while(num>0) {
			int temp = num%10;
			a=a*10+temp;
			num=num/10;
		}
		if(b==a) {
			System.out.println("it is palindrome");
			}
		else {
			System.out.println("not a palindrome");
		}

	}

}
