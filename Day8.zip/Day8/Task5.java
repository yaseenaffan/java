package Day8;

//CONSTRUCTOR WITH KEYWORD

public class Task5 {

	int age;
	String name;
	Task5(int age,String name)
	{
		this.age=age;
		this.name=name;
	}
	void display()
	{
		System.out.println(age+" "+name);
	}
	public static void main(String[] args) 
	{
		Task5 obj=new Task5(4,"yaseen");
		obj.display();
		

	}

}
// single ,multilevel,hiera rchial,multiple.