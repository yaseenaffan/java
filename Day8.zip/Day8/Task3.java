package Day8;

// STATIC VARIABLE USAGE

public class Task3 {
	
	int rollno = 100;
	String name = "yaseen";
	static String collegename="zion";
	
	void display(int a,String name) {
		System.out.println(a+" "+name+collegename);
	}

	public static void main(String[] args) {
		Task3 obj=new Task3();
		Task3.collegename =" zion";
		obj.display(100,"yaseen");
		obj.display(101,"senba");
		obj.display(102,"siva");
		
		
	}

}
