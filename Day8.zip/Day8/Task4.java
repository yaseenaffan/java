package Day8;

//CONSTRUCTOR

public class Task4 {
	
	int age;
	String name;
	Task4(){
		System.out.println("hi");
	}
	Task4(int a,String str){
		age = a;
		name = str;
	}
	void display() {
		System.out.println(age+" "+name);
	}
	public static void main(String[] args) {
		Task4 obj = new Task4();
		obj.age=19;
		obj.name="yaseen";
		System.out.println(obj.age);
		System.out.println(obj.name);
		
	} 
}
