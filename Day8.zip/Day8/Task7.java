package Day8;

// SINGLE INHERITANCE

class grandpa
{
	void display()
	{
		System.out.println("VILLA");
	}
}
class dad extends grandpa
{
	void property()
	{
		System.out.println("HOUSE,LANDS");
	}
}
class son extends dad
{
	void show()
	{
		System.out.println("BIKE");
	}
}
public class Task7{
	public static void main(String[] args) {
		son obj=new son();
		obj.display();
		obj.property();
		obj.show();
	}
}


