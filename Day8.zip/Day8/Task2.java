package Day8;

//STAIC AND INSTANCE OF VARIABLE

public class Task2 {
	int rollno=55;
	static String name ="affan";
	static String collegename="zion";
	
	void display(int a,String name)
	{
		System.out.println(a+" "+name+" "+collegename);
	}
	public static void show(int a) {
		Task2.name="affan";
		Task2.collegename="mount zion";
		System.out.println(a+" "+name +" "+collegename);
	}
	
	public static void main(String[] args) {
		Task2.show(55);
		Task2 obj=new Task2();
		obj.display(55,"yaseen");
	
	}
}
