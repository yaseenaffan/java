package Day8;

//OBJECT VARIABLE EX

public class Ooops {
	
	String trip = "kodaikanal";
	String place = "guna cave";
	int budget = 20000;
	
	public static void main(String[] args) {
		Ooops obj=new Ooops();
		System.out.println(obj.trip);
		Ooops obj1=new Ooops();
		System.out.println(obj.place);
		Ooops obj2=new Ooops();
		System.out.println(obj.budget);
              
	}

}        
                                              