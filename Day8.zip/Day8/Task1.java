package Day8;

// static keyword

public class Task1{
	
	int rollno=56;
	String name="senba";
	static String collegename="mount";
	
	void display(int a,String name)
	{
		System.out.println(a+""+name+collegename);
	}
	public static void main(String[] args) {
		Task1 obj=new Task1();
		Task1.collegename=" mount";
		obj.display(55," yaseen");
		obj.display(56," senba");
		obj.display(57," siva");
		obj.display(55," kishore");
		
		
	}
} 