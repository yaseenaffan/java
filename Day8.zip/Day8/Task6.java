package Day8;

// SINGLE INHERITANCCE

class Dad{
	void property()
	{
		System.out.println("house,lands");
	}
}
class Son extends Dad
{
	void show()
	{
		System.out.println("bike");
	}
}
public class Task6
{
	public static void main(String[] args){
		{
			Son obj=new Son();
			obj.property();
		}
	}

}