package Day7;

// METHOD CALL EXAMPLE

public class Task3 {
	public void display() {
			System.out.println("Hi nice to meet you ");
		}
	public static void main(String[] args) {
		Task3 obj=new Task3();
		obj.display();
	}

}
