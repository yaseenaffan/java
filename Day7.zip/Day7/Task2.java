package Day7;

// ADDITION USING METHOD

import java.util.*;
public class Task2 {

	public int add(int a,int b)
	{
		int sum=a+b;
		return sum;
	}
	public static void main(String[] args) {
		Task2 obj = new Task2();
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		int num2=sc.nextInt();
		int num3=sc.nextInt();
		int num4=sc.nextInt();
		System.out.println(obj);
	}

}
