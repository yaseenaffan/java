package Day7;

// METHOD RETURN STRING 

public class Task4 {

		public String display() {
			String name="yaseen";
			return name;
		}
		public static void main(String[] args)
		{
			Task4 obj=new Task4();
			String res=obj.display();
			System.out.println(res);
		}
	}

