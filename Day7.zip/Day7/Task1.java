package Day7;

// STRING OPERATION

public class Task1 {

	public static void main(String[] args) {

		String str="yaseen";
		String str1="affan";
		String str2=new String("yaseen");
		String str3=new String("yellowmatics");
		System.out.println(str==str1);
		System.out.println(str.equals(str2));
		System.out.println(str.equalsIgnoreCase(str2));
		System.out.println(str.length());
		System.out.println(str);
		String word[] = str.split(" ");
		for(String var:word)
		{
			System.out.println(var);
		}
		System.out.println(str3.substring(5));
		System.out.println(str3.contains("kis"));
		System.out.println(str3.endsWith("cs"));
		System.out.println(str3.charAt(3));
		System.out.println(str3.concat("gether"));
		
	}

}
