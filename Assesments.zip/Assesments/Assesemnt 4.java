package assessment;
import java.util.Scanner;
public class Day3homework {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        int rollnumber=scan.nextInt();
        if(rollnumber%47==0){
                
            System.out.println("YES");
        }
        else if(rollnumber%47!=0){
            System.out.println("NO");
        }
        else{
            System.out.println("InvalidInput");
        }
        
    }


	}


