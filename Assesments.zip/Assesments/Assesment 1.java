package assessment;
import java.util.Scanner;

public class Assessment {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		int a=scan.nextInt();
		int b=scan.nextInt();
		int div = a / b;
		int mod = a % b;
		System.out.println("The number of students in the team is " + div + " Left count is " + mod);
	}

}
