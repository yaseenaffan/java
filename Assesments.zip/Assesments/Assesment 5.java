package assessment;
import java.util.Scanner;
class Swapusingoperator {
	public static void main(String agrs[]) {
		Scanner scan=new Scanner(System.in);
		System.out.print("Enter the value1:");
		int a = scan.nextInt();
		System.out.print("Enter the value2:");
		int b = scan.nextInt();
		System.out.println("Before Swap: a ="+a+",b ="+b);
		a=a^b;
		b=a^b;
		a=a^b;
		System.out.println("After Swap: a ="+a+",b ="+b);
		}
	

}
