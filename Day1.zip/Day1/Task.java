
import java.util.Scanner;

public class main{
    public static void main(String args[]) {
       //long
       
       long phone= 8489437951L;
       
       // type casting 
        
       int num = 5;
       float num2 = num;
      
       // explicit type casting
       
       float num3 = 6.6f;
       int num4 = (int)num3;

       //short,byte,char if we add these three the output will be in integer

       byte num5 = 6;
       byte num6 = 8;
       byte num7 = (byte)(num5+num6);

       // ascii value for A-65,Z-90,a-97,z-122
       // in keywords we cant use any method or class
       
         //abstract    continue    for          new         switch
         //assert      default     goto*        package     synchronized
         //boolean     do          if           private     this
         //break       double      implements   protected   throw
         //byte        else        import       public      throws
         //case        enum        instanceof   return      transient
         //catch       extends     int          short       try
         //char        final       interface    static      void
         //class       finally     long         strictfp    volatile
         //const*      float       native       super       while
       
       
        Scanner sc = new Scanner(System.in);
         // scanner - class name, sc - object name, new scanner - constructor, system.in - input statement
         // int - data type , age - variable, sc - function call, nextInt() - method
         int age = sc.nextInt();
         sc.nextLine();
         String name = sc.nextLine();
         
                   char ch=sc.next().charAt(0);


         System.out.println(age);
         System.out.println(name);
         System.out.println(ch);
    }
}