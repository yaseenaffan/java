package Day9;

// ABSTACT CLASS

abstract class bike
    {
	abstract void run();
	}
	class honda extends bike
	{
		void run()
		{
			System.out.println("vehicle");
		}
		void play()
		{
			System.out.println("playing");
		}
	}
	public class Task1 
	{
		
	public static void main(String[] args) 
	{
		bike obj = new honda();
		obj.run();
		honda obj1 = new honda();
		obj1.play();
		
	}

}
