package Day9;

// SUPER KEYWORD

class animal
{
	String colour="red";
}
class bird
{
	String colour="purple";
	
	void eat()
	{
		System.out.println("eating");
	}
}
class dog extends bird
{
	void bark()
	{
		System.out.println("barking");
	}
	String colour = "white";
	void display()
	{
		System.out.println(colour);
		System.out.println(super.colour);
	}
}

public class Task5 {

	public static void main(String[] args) {
		dog obj = new dog();
		obj.display();
		
	}

}
