package Day9;



interface sum
{
	int max=100;
	void show ();
	static void display()
	{
		System.out.println("displaying");
	}
class Myclass implements sum
{
	public void show()
	{
		System.out.println("showing =");
	}
	
}

public class Task3{

	public static void main(String[] args) {
		sum.display();
		Myclass obj=new Myclass();
		obj.show();
	}
		
	}

}
